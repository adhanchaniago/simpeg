<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"></h1>
			</div>
		
		
		
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Tambah Unit Kerja</div>
					<div class="panel-body">
						
							<form action="" method="post" enctype="multipart/form-data">
							
								
																
								<div class="form-group">
									<label>Nama Unit Kerja</label>
									<input required maxlength="50" name="nama_unit_kerja" type="text" class="form-control">
								</div>
								
								<button name="submit" type="submit" class="btn btn-primary">Simpan</button>
								<button type="reset" class="btn btn-warning">Reset</button>
							
						</form>
					</div>
				</div>
			</div><!-- /.col-->
		
		
		
	</div>	<!--/.main-->