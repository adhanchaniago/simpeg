<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"></h1>
			</div>
		
		
		
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Tambah Pegawai</div>
					<div class="panel-body">
						
							<form action="" method="post" enctype="multipart/form-data">
							
								<div class="form-group">
									<label>NIP</label>
									<input name="nip" type="text" class="form-control" >
								</div>
																
								<div class="form-group">
									<label>Nama</label>
									<input name="nama" type="text" class="form-control">
								</div>
								
								<div class="form-group">
									<label>Golongan</label>
									<input name="golongan" type="text" class="form-control" >
								</div>
																
								<div class="form-group">
									<label>Username</label>
									<input name="username" type="text" class="form-control">
								</div>
								
								<div class="form-group">
									<label>Password</label>
									<input name="password" type="password" class="form-control">
								</div>
																
								
							
							
								
								
								
								<button name="submit" type="submit" class="btn btn-primary">Simpan</button>
								<button type="reset" class="btn btn-warning">Reset</button>
							
						</form>
					</div>
				</div>
			</div><!-- /.col-->
		
		
	</div>	<!--/.main-->